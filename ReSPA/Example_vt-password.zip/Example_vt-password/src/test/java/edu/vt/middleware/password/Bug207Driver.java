package edu.vt.middleware.password;


import java.util.ArrayList;
import java.util.List;





public class Bug207Driver {


	public static void main(String [] args) {


		try{




			String password1 = "aaaaaaaaaaabcdefg1H!";//make symbolic



			check(password1);//verify if valid






		}catch(Throwable e){
			e.printStackTrace();
		}








	}



	private static void check(String passwd) {
		boolean valid = true;
		StringPassword spw = new StringPassword(passwd);
		PasswordData pd = new PasswordData(spw);
		if(!assertLength(pd)){
			valid = false;
			System.out.println("This password does not have a valid length. Minimum is 8 characters and Maximum is 20 characters");
		}else System.out.println(" The length of the password is valid ");

		if(!assertAlphaNumeric(pd)){
			valid = false;
			System.out.println("This password does not have the minimum of 1 alpha numeric characters ");
		}else System.out.println(" This password has at least 1 alpha numeric character");

		if(!assertNonAlphaNumeric(pd)){
			valid = false;
			System.out.println("This password does not have the minimum of 1 non alpha numeric characters ");
		}else System.out.println(" This password has at least 1 non alpha numeric character ");

		if(!assertLCase(pd)){
			valid = false;
			System.out.println("This password does not have the minimum of 1 lower case characters ");
		}else System.out.println(" This password has at least 1 lower case character ");

		if(!assertUCase(pd)){
			valid = false;
			System.out.println("This password does not have the minimum of one upper case characters ");
		}else System.out.println(" This password has at least 1 upper case character ");

		if(!assertDigit(pd)){
			valid = false;
			System.out.println("This password does not have the minimum of one digit ");
		}else System.out.println(" This password has at least 1 digit");


		if(valid){

			System.out.println("The password is valid! "+passwd);
			assertRegex(pd);

		}
		else {
			System.out.println("Invalid Password! Try Again ");
		}
	}



	public static boolean assertLength(PasswordData pd) {

		LengthRule lr = new LengthRule(8, 20);
		final RuleResult result = lr.validate(pd);
		return result.valid;

	}


	public static boolean assertLCase(PasswordData pd) {

		LowercaseCharacterRule lcr = new LowercaseCharacterRule(1);
		final RuleResult result = lcr.validate(pd);
		return result.valid;

	}

	public static boolean assertUCase(PasswordData pd) {

		UppercaseCharacterRule ucr = new UppercaseCharacterRule(1);
		final RuleResult result = ucr.validate(pd);
		return result.valid;

	}

	public static boolean assertAlphaNumeric(PasswordData pd) {

		AlphabeticalCharacterRule acr = new AlphabeticalCharacterRule(1);
		final RuleResult result = acr.validate(pd);
		return result.valid;

	}

	public static boolean assertNonAlphaNumeric(PasswordData pd) {

		NonAlphanumericCharacterRule acr = new NonAlphanumericCharacterRule(1);
		final RuleResult result = acr.validate(pd);
		return result.valid;

	}

	public static boolean assertDigit(PasswordData pd) {

		DigitCharacterRule dcr = new DigitCharacterRule(1);
		final RuleResult result = dcr.validate(pd);
		return result.valid;

	}

	public static void assertRegex(PasswordData pd) {

		List<Rule> mandatoryRules = new ArrayList<Rule>();
		PasswordValidator validator = new PasswordValidator(mandatoryRules);
		String ALLOWED_CHARACTERS_REGEX;
		RegexRule regexRule;
		RuleResult rulesValidationresult ;
		boolean valid;

		//Regex Test 1: basic test
		ALLOWED_CHARACTERS_REGEX = "[s]";
		regexRule = new RegexRule(ALLOWED_CHARACTERS_REGEX);
		mandatoryRules.add(regexRule);
		rulesValidationresult = validator.validate(pd);
		valid = rulesValidationresult.isValid();
		if (valid) {
			System.out.println("Problem: should be invalid");
			throw new RuntimeException();

		} else {
			System.out.println("Passed");
		}

		//Regex Test 2: test whether the password only contains lc letters. It should fail
		ALLOWED_CHARACTERS_REGEX = "[a-z]";
		regexRule = new RegexRule(ALLOWED_CHARACTERS_REGEX);
		mandatoryRules.add(regexRule);
		rulesValidationresult = validator.validate(pd);
		valid = rulesValidationresult.isValid();
		if (valid) {
			System.out.println("Problem: should be invalid");
			throw new RuntimeException();

		} else {
			System.out.println("Passed");
		}

		//Regex Test 3: test whether the password only contains uc letters. It should fail
		ALLOWED_CHARACTERS_REGEX = "[A-Z]";
		regexRule = new RegexRule(ALLOWED_CHARACTERS_REGEX);
		mandatoryRules.add(regexRule);
		rulesValidationresult = validator.validate(pd);
		valid = rulesValidationresult.isValid();
		if (valid) {
			System.out.println("Problem: should be invalid");
			throw new RuntimeException();

		} else {
			System.out.println("Passed");
		}


		//Regex Test 4: test whether the password only contains numbers. It should fail.
		ALLOWED_CHARACTERS_REGEX = "[0-9]";
		regexRule = new RegexRule(ALLOWED_CHARACTERS_REGEX);
		mandatoryRules.add(regexRule);
		rulesValidationresult = validator.validate(pd);
		valid = rulesValidationresult.isValid();
		if (valid) {
			System.out.println("Problem: should be invalid");
			throw new RuntimeException();

		} else {
			System.out.println("Passed");
		}



	}




}
