/*
  $Id: SpringTest.java 2706 2013-04-26 14:29:59Z dfisher $

  Copyright (C) 2003-2013 Virginia Tech.
  All rights reserved.

  SEE LICENSE FOR MORE INFORMATION

  Author:  Middleware Services
  Email:   middleware@vt.edu
  Version: $Revision: 2706 $
  Updated: $Date: 2013-04-26 15:29:59 +0100 (Fri, 26 Apr 2013) $
*/
package edu.vt.middleware.password;

import java.util.ArrayList;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

/**
 * Unit test for Spring integration.
 *
 * @author  Middleware Services
 * @version  $Revision: 2706 $
 */
public class SpringTest
{


  /**
   * Attempts to load all Spring application context XML files to verify proper
   * wiring.
   *
   * @throws  Exception  On test failure.
   */
  @Test(groups = {"passtest"})
  public void testSpringWiring()
    throws Exception
  {
    final ClassPathXmlApplicationContext context =
      new ClassPathXmlApplicationContext(
        new String[] {"/spring-context.xml", });
    AssertJUnit.assertTrue(context.getBeanDefinitionCount() > 0);

    final PasswordValidator validator = new PasswordValidator(
      new ArrayList<Rule>(context.getBeansOfType(Rule.class).values()));
    final PasswordData pd = new PasswordData(new Password("springtest"));
    pd.setUsername("springuser");

    final RuleResult result = validator.validate(pd);
    AssertJUnit.assertNotNull(result);
  }
}
