/*
  $Id: RegexRuleTest.java 2706 2013-04-26 14:29:59Z dfisher $

  Copyright (C) 2003-2013 Virginia Tech.
  All rights reserved.

  SEE LICENSE FOR MORE INFORMATION

  Author:  Middleware Services
  Email:   middleware@vt.edu
  Version: $Revision: 2706 $
  Updated: $Date: 2013-04-26 15:29:59 +0100 (Fri, 26 Apr 2013) $
*/
package edu.vt.middleware.password;

import org.testng.AssertJUnit;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Unit test for {@link RegexRule}.
 *
 * @author  Middleware Services
 * @version  $Revision: 2706 $
 */
public class RegexRuleTest extends AbstractRuleTest
{


  /**
   * @return  Test data.
   *
   * @throws  Exception  On test data generation failure.
   */
  @DataProvider(name = "passwords")
  public Object[][] passwords()
    throws Exception
  {
    return
      new Object[][] {
        // test valid password
        {
          new RegexRule("\\d\\d\\d\\d"),
          new PasswordData(new Password("p4zRcv8#n65")),
          null,
        },
        // test entire password
        {
          new RegexRule("^[\\p{Alpha}]+\\d\\d\\d\\d$"),
          new PasswordData(new Password("pwUiNh0248")),
          codes(RegexRule.ERROR_CODE),
        },
        // test find password
        {
          new RegexRule("\\d\\d\\d\\d"),
          new PasswordData(new Password("pwUi0248xwK")),
          codes(RegexRule.ERROR_CODE),
        },
      };
  }


  /** @throws  Exception  On test failure. */
  @Test(groups = {"passtest"})
  public void resolveMessage()
    throws Exception
  {
    final Rule rule = new RegexRule("\\d\\d\\d\\d");
    final RuleResult result = rule.validate(
      new PasswordData(new Password("pwUiNh0248")));
    for (RuleResultDetail detail : result.getDetails()) {
      AssertJUnit.assertEquals(
        String.format("Password matches the illegal sequence '%s'.", "0248"),
        DEFAULT_RESOLVER.resolve(detail));
      AssertJUnit.assertNotNull(EMPTY_RESOLVER.resolve(detail));
    }
  }
}
