package edu.vt.middleware.password;

/**
 * jmatos: I use this class to circumvent StringBuilder objects at the Password.java
 */
public class StringPassword extends Password{


	/** Stores the password. */
	private  String password;

	/** Digits in the password [0-9]. */
	private  String digits="";

	/** Non-Digits in the password ![0-9]. */
	private  String nonDigits="";

	/** Alphabetical characters in the password [a-zA-Z]. */
	private  String alphabetical="";

	/** Non-Alphabetical characters in the password ![a-zA-Z]. */
	private  String nonAlphabetical="";

	/** Alphanumeric characters in the password [a-zA-Z0-9]. */
	private  String alphanumeric="";

	/** Non-Alphanumeric characters in the password ![a-zA-Z0-9]. */
	private  String nonAlphanumeric="";

	/** Uppercase characters in the password [A-Z]. */
	private  String uppercase="";

	/** Lowercase characters in the password [a-z]. */
	private  String lowercase="";

	/** Whitespace characters in the password [\s]. */
	private  String whitespace="";

	public StringPassword(String text) {
		super();

		password = text;
		
		for (int i = 0; i < text.length(); i++) {

			char c = password.charAt(i);

			if (c>='0'&&c<='9') {
				digits=digits+c;
				alphanumeric=alphanumeric+c;
				nonAlphabetical=nonAlphabetical+c;
			} 
			else if (c>='a'&&c<='z'){
				nonDigits = nonDigits+c;
				alphanumeric = alphanumeric+c;
				alphabetical=alphabetical+c;
				lowercase=lowercase+c;
			}
			else if(c>='A'&&c<='Z') {
				nonDigits = nonDigits+c;
				alphanumeric = alphanumeric+c;
				alphabetical=alphabetical+c;
				uppercase=uppercase+c;
			}
			else if (Character.isWhitespace(c)) {
				whitespace=whitespace+c;
				nonDigits= nonDigits+c;
				nonAlphanumeric= nonAlphanumeric+c;
				nonAlphabetical=nonAlphabetical+c;
			}
			else {
				nonDigits= nonDigits+c;
				nonAlphanumeric= nonAlphanumeric+c;
				nonAlphabetical=nonAlphabetical+c;
			}

		}



	}


	/**
	 * Returns the text of this password.
	 *
	 * @return  password
	 */
	@Override
	public String getText()
	{
		return password;
	}


	/**
	 * Returns the length of this password.
	 *
	 * @return  password length
	 */
	@Override
	public int length()
	{
		return password.length();
	}



	/**
	 * Returns whether or not this password contains digits.
	 *
	 * @return  whether or not the password contains digits
	 */
	@Override
	public boolean containsDigits()
	{
		return digits.length() > 0;
	}


	/**
	 * Returns the number of digits in this password.
	 *
	 * @return  number of digits in the password
	 */
	@Override
	public int getNumberOfDigits()
	{
		return digits.length();
	}
























	/**
	 * Returns the digits in this password.
	 *
	 * @return  digits in this password
	 */
	@Override
	public char[] getDigits()
	{
		char[] array = null;
		if (digits != null && digits.length() > 0) {
			array = digits.toString().toCharArray();
		}
		return array;
	}


	/**
	 * Returns whether or not this password contains non-digits.
	 *
	 * @return  whether or not the password contains non-digits
	 */
	@Override
	public boolean containsNonDigits()
	{
		return nonDigits.length() > 0;
	}


	/**
	 * Returns the number of non-digits in this password.
	 *
	 * @return  number of non-digits in this password
	 */
	@Override
	public int getNumberOfNonDigits()
	{
		return nonDigits.length();
	}


	/**
	 * Returns the non-digits in this password.
	 *
	 * @return  non-digits in this password
	 */
	@Override
	public char[] getNonDigits()
	{
		char[] array = null;
		if (nonDigits != null && nonDigits.length() > 0) {
			array = nonDigits.toString().toCharArray();
		}
		return array;
	}


	/**
	 * Returns whether or not this password contains alphabetical characters.
	 *
	 * @return  whether or not the password contains alphabetical characters
	 */
	@Override
	public boolean containsAlphabetical()
	{
		return alphabetical.length() > 0;
	}


	/**
	 * Returns the number of alphabetical characters in this password.
	 *
	 * @return  number of alphabetical characters in this password
	 */
	@Override
	public int getNumberOfAlphabetical()
	{
		return alphabetical.length();
	}


	/**
	 * Returns the alphabetical characters in this password.
	 *
	 * @return  alphabetical characters in this password
	 */
	@Override
	public char[] getAlphabetical()
	{
		char[] array = null;
		if (alphabetical != null && alphabetical.length() > 0) {
			array = alphabetical.toString().toCharArray();
		}
		return array;
	}


	/**
	 * Returns whether or not this password contains non-alphabetical characters.
	 *
	 * @return  whether or not the password contains non-alphabetical characters
	 */
	@Override
	public boolean containsNonAlphabetical()
	{
		return nonAlphabetical.length() > 0;
	}


	/**
	 * Returns the number of non-alphabetical characters in this password.
	 *
	 * @return  number of non-alphabetical characters in this password
	 */
	@Override
	public int getNumberOfNonAlphabetical()
	{
		return nonAlphabetical.length();
	}


	/**
	 * Returns the non-alphabetical characters in this password.
	 *
	 * @return  non-alphabetical characters in this password
	 */
	@Override
	public char[] getNonAlphabetical()
	{
		char[] array = null;
		if (nonAlphabetical != null && nonAlphabetical.length() > 0) {
			array = nonAlphabetical.toString().toCharArray();
		}
		return array;
	}


	/**
	 * Returns whether or not this password contains alphanumeric characters.
	 *
	 * @return  whether or not the password contains alphanumeric characters
	 */
	@Override
	public boolean containsAlphanumeric()
	{
		return alphanumeric.length() > 0;
	}


	/**
	 * Returns the number of alphanumeric characters in this password.
	 *
	 * @return  number of alphanumeric characters in this password
	 */
	@Override
	public int getNumberOfAlphanumeric()
	{
		return alphanumeric.length();
	}


	/**
	 * Returns the alphanumeric characters in this password.
	 *
	 * @return  alphanumeric characters in this password
	 */
	@Override
	public char[] getAlphanumeric()
	{
		char[] array = null;
		if (alphanumeric != null && alphanumeric.length() > 0) {
			array = alphanumeric.toString().toCharArray();
		}
		return array;
	}


	/**
	 * Returns whether or not this password contains non-alphanumeric characters.
	 *
	 * @return  whether or not the password contains non-alphanumeric characters
	 */
	@Override
	public boolean containsNonAlphanumeric()
	{
		return nonAlphanumeric.length() > 0;
	}


	/**
	 * Returns the number of non-alphanumeric characters in this password.
	 *
	 * @return  number of non-alphanumeric characters in this password
	 */
	@Override
	public int getNumberOfNonAlphanumeric()
	{
		return nonAlphanumeric.length();
	}


	/**
	 * Returns the non-alphanumeric characters in this password.
	 *
	 * @return  non-alphanumeric characters in this password
	 */
	@Override
	public char[] getNonAlphanumeric()
	{
		char[] array = null;
		if (nonAlphanumeric != null && nonAlphanumeric.length() > 0) {
			array = nonAlphanumeric.toString().toCharArray();
		}
		return array;
	}


	/**
	 * Returns whether or not this password contains uppercase characters.
	 *
	 * @return  whether or not the password contains uppercase characters
	 */
	@Override
	public boolean containsUppercase()
	{
		return uppercase.length() > 0;
	}


	/**
	 * Returns the number of uppercase characters in this password.
	 *
	 * @return  number of uppercase characters in this password
	 */
	@Override
	public int getNumberOfUppercase()
	{
		return uppercase.length();
	}


	/**
	 * Returns the uppercase characters in this password.
	 *
	 * @return  uppercase characters in this password
	 */
	@Override
	public char[] getUppercase()
	{
		char[] array = null;
		if (uppercase != null && uppercase.length() > 0) {
			array = uppercase.toString().toCharArray();
		}
		return array;
	}


	/**
	 * Returns whether or not this password contains lowercase characters.
	 *
	 * @return  whether or not the password contains uppercase characters
	 */
	@Override
	public boolean containsLowercase()
	{
		return lowercase.length() > 0;
	}


	/**
	 * Returns the number of lowercase characters in this password.
	 *
	 * @return  number of lowercase characters in this password
	 */
	@Override
	public int getNumberOfLowercase()
	{
		return lowercase.length();
	}


	/**
	 * Returns the lowercase characters in this password.
	 *
	 * @return  lowercase characters in this password
	 */
	@Override
	public char[] getLowercase()
	{
		char[] array = null;
		if (lowercase != null && lowercase.length() > 0) {
			array = lowercase.toString().toCharArray();
		}
		return array;
	}


	/**
	 * Returns whether or not this Password contains whitespace characters.
	 *
	 * @return  whether or not the password contains whitespace characters
	 */
	@Override
	public boolean containsWhitespace()
	{
		return whitespace.length() > 0;
	}


	/**
	 * Returns the number of whitespace characters in this password.
	 *
	 * @return  number of whitespace characters in this password
	 */
	@Override
	public int getNumberOfWhitespace()
	{
		return whitespace.length();
	}


	/**
	 * Returns the whitespace characters in this password.
	 *
	 * @return  whitespace characters in this password
	 */
	@Override
	public char[] getWhitespace()
	{
		char[] array = null;
		if (whitespace != null && whitespace.length() > 0) {
			array = whitespace.toString().toCharArray();
		}
		return array;
	}


	/** {@inheritDoc} */
	@Override
	public String toString()
	{
		return password;
	}

}
