PASSWORD ${project.version} README

    This is the ${project.version} release of the VT Password libraries.
    It is dual licensed under both the LGPL and Apache 2.
    If you have questions or comments about this library send e-mail to
    vt-middleware-users@googlegroups.com.

DOCUMENTATION
    See the wiki: http://code.google.com/p/vt-middleware/wiki/vtpassword

